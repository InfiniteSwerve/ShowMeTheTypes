from setuptools import setup, find_packages

setup(
    name="show_me_the_types",
    version="0.1",
    packages=find_packages(),
    install_requires=[],
)
